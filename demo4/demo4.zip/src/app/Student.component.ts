import { Component } from '@angular/core';

@Component({
  selector: 'student-app',
  templateUrl: './student.html'
})
export class StudentComponent
  {
    
     name = 'Angular';
     marks:number= 203;
     }
