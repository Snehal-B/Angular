"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
//import {Input} from '@angular/core'
var GradeComponent = (function () {
    function GradeComponent() {
        this.marks = 50;
        this.grade = "";
        console.log("in con " + this.marks);
    }
    GradeComponent.prototype.ngOnChanges = function (changes) {
        console.log("on changes ");
        console.log(changes);
        if (this.marks > 35)
            this.grade = "Pass";
        else
            this.grade = "Fail";
    };
    GradeComponent.prototype.ngOnInit = function () {
        console.log("ngOnIniit" + this.marks);
        if (this.marks > 35)
            this.grade = "Pass";
        else
            this.grade = "Fail";
    };
    return GradeComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], GradeComponent.prototype, "marks", void 0);
GradeComponent = __decorate([
    core_1.Component({
        selector: 'grade-app',
        templateUrl: './grade.html'
    }),
    __metadata("design:paramtypes", [])
], GradeComponent);
exports.GradeComponent = GradeComponent;
//# sourceMappingURL=Grade.component.js.map